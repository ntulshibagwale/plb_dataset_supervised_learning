4-12-2022

4 angles, can it classify them using a neural network.
Yes. It seems we can get greater than 90% accuracy pretty
easily, using only 50% of the training set. 

I think sinking more time into improving accuracy isn't a 
good use of time. 

Looking at regression, the ability of extrapolating to new
unseen signals and determine the angle at which they were 
generated would be interesting.


Update 5-25-2022
Tried regression for a little while, don't think its worth 
more time for now. Archiving this old stuff so I can
give classification another go with updated code